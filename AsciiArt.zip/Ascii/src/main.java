
public class main {

	public static void main(String[] args) {
		
		Image2Ascii image2ascii = new Image2Ascii();
		image2ascii.LoadImage("cat.png");
		image2ascii.print();

	}

}
